public class ATM {
    public float Balance = 0;
    public boolean A = false;
    public boolean isCorrectCard = true;
    public boolean ValidPassword = true;

    public String deposit(float money){
        if(A){
            if(money >= 50 && money <=50000){
                Balance += money;
                return "Successful deposit";
            }
            else{
                return "Enter valid amount";
            }
        }
        else{
            return "Error";
        }
    }



    public String removeCard(){
        if(isCorrectCard){
            return "Card removed";
        }
        else{
            return "Error";
        }
    }

    public String enterCard(){
        if(isCorrectCard){
            return "Valid card";
        }
        else{
            return "Card is not valid";
        }
    }


    public String enterPassword(){
        if(isCorrectCard){
            System.out.println("Enter Password");
            if(ValidPassword){
                A = true;
                return "login successfully";
            }
            else{
                return "Wrong password";
            }
        }
        else{
            return "Enter card first";
        }
    }


    public String withdraw(float amount){
        if(A){
            if(amount <= Balance){
                Balance -= amount;
                return "Successful withdraw";
            }
            else{
                return "Not enough balance";
            }
        }
        else{
            return "Error";
        }
    }


}