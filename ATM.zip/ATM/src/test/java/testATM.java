import org.junit.Test;
import static org.junit.Assert.*;
public class testATM {

    // trying invalid card
    @Test
    public void test1(){
        ATM a = new ATM();
        a.isCorrectCard = false;
        assertEquals("Card is not valid",a.enterCard());
    }
    // trying a valid card
    @Test
    public void test2(){
        ATM a = new ATM();
        assertEquals("Valid card",a.enterCard());
    }
    // loging in successfully
    @Test
    public void test3(){
        ATM a = new ATM();
        assertEquals("login successfully",a.enterPassword());
    }
    // trying a valid card and wrong password
    @Test
    public void test4(){
        ATM a = new ATM();
        assertEquals("Valid card",a.enterCard());
        a.ValidPassword = false;
        assertEquals("Wrong password",a.enterPassword());
    }
    // trying to withdraw an amount of money with no balance
    @Test
    public void test5(){
        ATM a = new ATM();
        assertEquals("Valid card",a.enterCard());
        assertEquals("login successfully",a.enterPassword());
        assertEquals("Not enough balance",a.withdraw(10));
    }
    // trying to enter an amount of money <50
    @Test
    public void test6(){
        ATM a = new ATM();
        assertEquals("Valid card",a.enterCard());
        assertEquals("login successfully",a.enterPassword());
        assertEquals("Enter valid amount",a.deposit(20));
        assertEquals("Not enough balance",a.withdraw(10));
    }
    // trying to enter an amount of money =50
    @Test
    public void test7(){
        ATM a = new ATM();
        assertEquals("Valid card",a.enterCard());
        assertEquals("login successfully",a.enterPassword());
        assertEquals("Successful deposit",a.deposit(50));
        assertEquals("Successful withdraw",a.withdraw(10));
    }
    // successful deposit and successful withdraw
    @Test
    public void test8(){
        ATM a = new ATM();
        assertEquals("Valid card",a.enterCard());
        assertEquals("login successfully",a.enterPassword());
        assertEquals("Successful deposit",a.deposit(1000));
        assertEquals("Successful withdraw",a.withdraw(10));
    }
    // successful deposit and invalid withdraw
    @Test
    public void test9(){
        ATM a = new ATM();
        assertEquals("Valid card",a.enterCard());
        assertEquals("login successfully",a.enterPassword());
        assertEquals("Enter valid amount",a.deposit(300200));
        assertEquals("Not enough balance",a.withdraw(100));
    }
    // successful deposit successful withdraw invalid withdraw and successful withdraw
    @Test
    public void test10(){
        ATM a = new ATM();
        assertEquals("Valid card",a.enterCard());
        assertEquals("login successfully",a.enterPassword());
        assertEquals("Successful deposit",a.deposit(1000));
        assertEquals("Successful withdraw",a.withdraw(100));
        assertEquals("Not enough balance",a.withdraw(3000));
        assertEquals("Successful withdraw",a.withdraw(200));
    }
}
