import static org.junit.Assert.*;
import org.junit.Test;
public class testCoffeeMachine {

    //switching on the machine and adding money successfully
    @Test
    public void test1(){
        CoffeeMachine c = new CoffeeMachine();
        assertEquals("Power is switched on" + "Lights are switched On",c.TurnMachineOn());
        assertEquals(("money added successfully"),c.insertMoney(5));
        assertEquals(1+ " coffee cups made!",c.makeCoffee(1));
    }

    // adding money and the machine isn't switched on
    @Test
    public void test2(){
        CoffeeMachine c = new CoffeeMachine();
        c.TurnMachineOn();
        c.TurnMachineOff();
        assertEquals("switch on the machine first!",c.insertMoney(30));
    }

    //switching on successfully and adding money
    @Test
    public void test3(){
        CoffeeMachine c = new CoffeeMachine();
        assertEquals("Power is switched on" + "Lights are switched On",c.TurnMachineOn());
        assertEquals("money added successfully",c.insertMoney(30));
    }

    @Test
    public void test4(){
        CoffeeMachine c= new CoffeeMachine();
        c.powerOn = true;
        assertEquals("Error",c.TurnMachineOn());
    }

    // //switching on successfully and adding money then closing the machine
    @Test
    public void test5(){
        CoffeeMachine c = new CoffeeMachine();
        assertEquals("Power is switched on" + "Lights are switched On",c.TurnMachineOn());
        assertEquals(("money added successfully"),c.insertMoney(30));
        assertEquals("Lights are switched off" + "Power is switched Off",c.TurnMachineOff());
    }

    //trying to make coffee without switching the machine on
    @Test
    public void test6(){
        CoffeeMachine c = new CoffeeMachine();
        assertEquals("switch on the machine first!",c.makeCoffee(2));
    }

    //making coffee successfully
    @Test
    public void test7(){
        CoffeeMachine c = new CoffeeMachine();
        assertEquals("Power is switched on" + "Lights are switched On",c.TurnMachineOn());
        assertEquals(("money added successfully"),c.insertMoney(30));
        assertEquals(3+ " coffee cups made!",c.makeCoffee(3));
    }

    // checking the number of cups produced
    @Test
    public void test8(){
        CoffeeMachine c = new CoffeeMachine();
        assertEquals("Power is switched on" + "Lights are switched On",c.TurnMachineOn());
        assertEquals(("money added successfully"),c.insertMoney(20));
        assertEquals(4+ " coffee cups made!",c.makeCoffee(4));
    }

    // switching on the machine
    @Test
    public void test9(){
        CoffeeMachine c = new CoffeeMachine();
        assertEquals("Power is switched on" + "Lights are switched On",c.TurnMachineOn());
    }

    //making coffee successfully and then closing the machine
    @Test
    public void test10(){
        CoffeeMachine c = new CoffeeMachine();
        assertEquals("Power is switched on" + "Lights are switched On",c.TurnMachineOn());
        assertEquals("money added successfully",c.insertMoney(30));
        assertEquals(2+ " coffee cups made!",c.makeCoffee(2));
        assertEquals("Lights are switched off" + "Power is switched Off",c.TurnMachineOff());
    }
}