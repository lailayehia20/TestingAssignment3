public class CoffeeMachine {
    public boolean lightOn = false;
    public boolean powerOn = false;
    public float money;
    public boolean busy = false;
    private final float price = 5;
    public int coffeeAmount;

    public String makeCoffee(int coffeeAmount){
        if(powerOn) {
            int i= 0;
            if (money >= price) {
                while(money>= price && coffeeAmount > 0){
                    money -= price;
                    busy = true;
                    coffeeAmount --;
                    i++;
                }
            }
            else {
                return "no balance";
            }
            busy = false;
            return i+ " coffee cups made!";
        }
        else{
            return "switch on the machine first!";
        }
    }

    public String insertMoney(float money){
        if(powerOn) {
            this.money = money;
            return "money added successfully";
        }
        else{
            return "switch on the machine first!";
        }
    }

    public String TurnMachineOn(){
        if(!powerOn) {
            powerOn = true;
            lightOn = true;
            return "Power is switched on" + "Lights are switched On";
        }
        else{
            return "Error";
        }
    }


    public String TurnMachineOff(){
        if(powerOn) {
            lightOn = false;
            powerOn = false;
            return "Lights are switched off" + "Power is switched Off";
        }
        else{
            return "Error";
        }
    }

}