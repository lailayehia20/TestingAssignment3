import org.junit.Test;
import static org.junit.Assert.*;
public class testDigitalWatch {

    // opening the watch
    @Test
    public void test1(){
        digitalWatch d = new digitalWatch();
        assertEquals("The watch is turned on",d.turnOn());
    }

    // switching on the watch 2 times
    @Test
    public void test2(){
        digitalWatch d = new digitalWatch();
        assertEquals("The watch is turned on",d.turnOn());
        assertEquals("The watch is turned on already",d.turnOn());
    }

    // switching on the watch 2 times and then switching it off
    @Test
    public void test3(){
        digitalWatch d = new digitalWatch();
        assertEquals("The watch is turned on",d.turnOn());
        assertEquals("The watch is turned on already",d.turnOn());
        assertEquals("The watch is turned off",d.turnOff());
    }

    //switching on the watch and setting timer
    @Test
    public void test4(){
        digitalWatch d = new digitalWatch();
        assertEquals("The watch is turned on",d.turnOn());
        assertEquals("Timer set",d.setTimer(10));
    }

    //switching on the watch and setting timer and waiting for it to end
    @Test
    public void test5(){
        digitalWatch d = new digitalWatch();
        assertEquals("The watch is turned on",d.turnOn());
        assertEquals("Timer set",d.setTimer(10));
        assertEquals("Wait for timer to end",d.doSth());
    }

    // checking that the timer has ended
    @Test
    public void test6(){
        digitalWatch d = new digitalWatch();
        assertEquals("The watch is turned on",d.turnOn());
        assertEquals("Timer set",d.setTimer(20));
        d.TimerSetChecker = false;
        assertEquals("Accepted",d.doSth());
    }

    // setting timer and then waiting for it to end and then closing the watch
    @Test
    public void test7(){
        digitalWatch d = new digitalWatch();
        assertEquals("The watch is turned on",d.turnOn());
        assertEquals("Timer set",d.setTimer(20));
        assertEquals("Wait for timer to end",d.doSth());
        d.TimerSetChecker = false;
        assertEquals("Accepted",d.doSth());
        assertEquals("The watch is turned off",d.turnOff());
    }
    @Test
    public void test8(){
        digitalWatch d = new digitalWatch();
        assertEquals("The watch is turned on",d.turnOn());
        assertEquals("Timer set",d.setTimer(10));
        d.TimerSetChecker = false;
        assertEquals("Accepted",d.doSth());
        d.OpenChecker = false;
        assertEquals("Error",d.turnOff());
    }
}