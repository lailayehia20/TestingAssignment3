public class digitalWatch {

    public float timer = 0;
    public boolean OpenChecker = false;
    public boolean TimerSetChecker = false;


    public String setTimer(float time){
        if(OpenChecker){
            timer = time;
            TimerSetChecker = true;
            return "Timer set";
        }
        else{
            return "The watch is closed";
        }
    }


    public String turnOn(){
        if(!OpenChecker){
            OpenChecker = true;
            return "The watch is turned on";
        }
        else{
            return "The watch is turned on already";
        }
    }


    public String turnOff(){
        if(OpenChecker){
            OpenChecker = false;
            return "The watch is turned off";
        }
        else{
            return "Error";
        }
    }


    public String doSth(){
        if(TimerSetChecker){
            return "Wait for timer to end";
        }
        else{
            return "Accepted";
        }
    }

}